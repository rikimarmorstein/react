enum Category {
    FOOD = "FOOD",
    ELECTRICITY = "ELECTRICITY",
    RESTAURANT = "RESTAURANT",
    VACATION = "VACATION"
}


export default Category;