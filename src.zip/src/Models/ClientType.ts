enum ClientType {
    CUSTOMER = "CUSTOMER",
    COMPANY = "COMPANY",
    ADMINISTRATOR = "ADMIN"
}

export default ClientType;
