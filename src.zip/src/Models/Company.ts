class Company {

    public id: number;
    public name: string;
    public email: string;
    public password: string;

}

export default Company;

